Armor expansion
===============================

License Source Code: Copyright (C) 2013-2023 Stuart Jones - LGPL v2.1

Armor Textures: Copyright (C) 2017-2023 davidthecreator - CC-BY-SA 3.0

Gambit (CC BY-SA 3.0):
  default_iron_lump.png

BlockMen (CC BY-SA 3.0):
  default_iron_ingot.png

Tool breaking sounds added by sofar: CC-BY-3.0
  default_tool_breaks.* - http://www.freesound.org/people/HerbertBoland/sounds/33206/

Glass breaking sounds (CC BY 3.0):
  1: http://www.freesound.org/people/cmusounddesign/sounds/71947/
  2: http://www.freesound.org/people/Tomlija/sounds/97669/
  3: http://www.freesound.org/people/lsprice/sounds/88808/

